#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include <cmath>
using namespace std;

class SignedBinaryUIConverter {
private:
	long long _value;
	int _bitRange;
public:
	SignedBinaryUIConverter() {
		_value = 0;
		_bitRange = 0;
	}
	SignedBinaryUIConverter(int value, int bitRange) {
		_value = value;
		_bitRange = bitRange;
	}
public:
	bool isValidDec(long long, int);
	bool isValidBin(string);
	vector<int>	convertDecToBin(long long, int);
	long long convertBinToDec(string);
	string toString(vector<int>);
	vector<int> convertBack(string);
public:
	vector<int> getBinaryPlusOne(vector<int>);
	void reverseBinary(vector<int>&);
};
